# Travel-website
✈️ A Simple Tour or Travel Booking Website using Html, Css &amp; Javascript Hello there, I'm Saritha Rachapudi and I made this Tour&amp;travel Booking Website. 
🌐 This Website is made with Html, CSS &amp; Javascript.
It contains MenuBar, search bar to search hotel/Location, Header,Arrivals, Leaving, destination&amp; Footer as well. 
It has different modules used are Packages &amp; Contact. 
Basic Html &amp; CSS plays an important role here making whole website more attractive and responsive for all devices. 
Different packages are included to make website user friendly and more responsive towards making their trip more comfortable, luxurious and safer.

Assets :font-awesome cdn toolkit, poppins google font toolkit,  animation-on-scroll